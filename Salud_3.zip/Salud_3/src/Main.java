
import java.util.Scanner;

public class Main {

    static Scanner leer = new Scanner(System.in);
    static Sistema sistema = new Sistema();

    public static void main(String[] args) {

        int opcion;

        do {

            mostrarMenu();
            opcion = leer.nextInt();

            switch (opcion) {

                case 1:
                    sistema.registrarConsulta(leer);
                    break;

                case 2:
                    sistema.buscarConsulta(leer);
                    break;

                case 3:
                    sistema.mostrarConsultas();
                    break;

                case 4:
                    sistema.mostrarInformacion();
                    break;

                case 5:
                    System.out.println("Gracias por utilizar el sistema.");
                    break;

                default:
                    System.out.println("Opción incorrecta.");
            }

        } while (opcion != 5);

        leer.close();
    }

    public static void mostrarMenu() {

        System.out.println();
        System.out.println(" ");
        System.out.println("SISTEMA DE ORIENTACIÓN EN SALUD");
        System.out.println(" ");
        System.out.println("1. Iniciar orientación médica");
        System.out.println("2. Recuperar una recomendación anterior");
        System.out.println("3. Ver reportes estadísticos");
        System.out.println("4. Información del sistema");
        System.out.println("5. Salir");
        System.out.print("Seleccione una opción: ");
    }
}